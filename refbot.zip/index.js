require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const sqlite3 = require('sqlite3').verbose();
const fetch = require('node-fetch');

const token = process.env.TELEGRAM_BOT_TOKEN;
const bot = new TelegramBot(token, { polling: true });

const groupFreeId = -4271597388;
const groupVipId = -4102118890;

// Database setup
const db = new sqlite3.Database(':memory:');

db.serialize(() => {
  db.run("CREATE TABLE users (id INTEGER PRIMARY KEY, telegram_id TEXT, invited_count INTEGER DEFAULT 0)");
  db.run("CREATE TABLE invites (id INTEGER PRIMARY KEY, inviter_id INTEGER, invitee_id INTEGER)");
});

// Start command
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  db.get("SELECT * FROM users WHERE telegram_id = ?", [userId], (err, row) => {
    if (err) {
      console.error(err);
      return;
    }
    if (row) {
      bot.sendMessage(chatId, "Sei già registrato! Usa /promo per vedere la promo attuale.");
    } else {
      bot.sendMessage(chatId, "Verifica il tuo profilo risolvendo questo captcha: 2+2=?", {
        reply_markup: {
          inline_keyboard: [[{ text: "4", callback_data: "captcha_correct" }, { text: "5", callback_data: "captcha_wrong" }]]
        }
      });
    }
  });
});

// Captcha verification
bot.on('callback_query', (query) => {
  const userId = query.from.id;
  const chatId = query.message.chat.id;

  if (query.data === 'captcha_correct') {
    db.run("INSERT INTO users (telegram_id) VALUES (?)", [userId], (err) => {
      if (err) {
        console.error(err);
        return;
      }
      bot.sendMessage(chatId, "Profilo verificato! Usa /promo per vedere la promo attuale.");
    });
  } else if (query.data === 'captcha_wrong') {
    bot.sendMessage(chatId, "Captcha errato! Riprova con /start.");
  }
});

// Promo command
bot.onText(/\/promo/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  db.get("SELECT * FROM users WHERE telegram_id = ?", [userId], (err, row) => {
    if (err) {
      console.error(err);
      return;
    }
    if (row) {
      bot.sendMessage(chatId, "Partecipa alla promo! Invita 3 persone e ottieni l'accesso al gruppo VIP.", {
        reply_markup: {
          inline_keyboard: [[{ text: "Partecipa alla promo", callback_data: "join_promo" }]]
        }
      });
    } else {
      bot.sendMessage(chatId, "Non sei registrato! Usa /start per verificare il tuo profilo.");
    }
  });
});

// Join promo
bot.on('callback_query', (query) => {
  const userId = query.from.id;
  const chatId = query.message.chat.id;

  if (query.data === 'join_promo') {
    const inviteLink = `https://t.me/+naRTJEejM79iMTE0?start=${userId}`;
    bot.sendMessage(chatId, `Usa questo link per invitare i tuoi amici: ${inviteLink}`);

    // Save the invite link to the database
    db.run("INSERT INTO invites (inviter_id) VALUES (?)", [userId], (err) => {
      if (err) {
        console.error(err);
      }
    });
  }
});

// Challenge command
bot.onText(/\/challenge/, (msg) => {
  const userId = msg.from.id;

  db.get("SELECT COUNT(*) AS count FROM invites WHERE inviter_id = ? AND invitee_id IS NOT NULL", [userId], (err, row) => {
    if (err) {
      console.error(err);
      return;
    }
    const count = row.count;
    const remaining = 3 - count;
    let response = `Hai invitato ${count} persone.`;

    if (remaining > 0) {
      response += ` Te ne mancano ${remaining} per accedere al gruppo VIP.`;
    } else {
      response += " Hai ottenuto l'accesso al gruppo VIP!";
      // Send VIP group link
      bot.sendMessage(userId, "Complimenti! Ecco il link per accedere al gruppo VIP: https://t.me/+8p9nugQ7njo0ZTI0");
    }

    bot.sendMessage(msg.chat.id, response);
  });
});

// Welcome new users and verify captcha in free group
bot.on('new_chat_members', (msg) => {
  const chatId = msg.chat.id;
  const newUserId = msg.new_chat_participant.id;

  if (chatId === groupFreeId) {
    bot.sendMessage(chatId, `Benvenuto! Verifica il tuo profilo risolvendo questo captcha: 3+2=?`, {
      reply_markup: {
        inline_keyboard: [[{ text: "5", callback_data: "captcha_correct" }, { text: "6", callback_data: "captcha_wrong" }]]
      }
    });
  }
});

// Handle new VIP group members
bot.on('new_chat_members', (msg) => {
  const chatId = msg.chat.id;
  const newUserId = msg.new_chat_participant.id;

  if (chatId === groupVipId) {
    db.get("SELECT * FROM users WHERE telegram_id = ? AND invited_count >= 3", [newUserId], (err, row) => {
      if (err) {
        console.error(err);
        return;
      }
      if (row) {
        bot.sendMessage(chatId, "Benvenuto nel gruppo VIP!");
      } else {
        bot.kickChatMember(groupVipId, newUserId).then(() => {
          bot.sendMessage(chatId, "Non hai i requisiti per entrare nel gruppo VIP. Unisciti al gruppo free e partecipa alla promo!");
        }).catch(console.error);
      }
    });
  }
});

// Restart bot on connection loss
bot.on('polling_error', (error) => {
  console.error(`Polling error: ${error.message}. Riavvio del bot in corso...`);
  setTimeout(() => {
    process.exit(1);
  }, 3000);
});
